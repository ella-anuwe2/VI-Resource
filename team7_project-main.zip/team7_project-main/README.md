<div id="top"></div>
<!--
*** Thanks for checking out the Best-README-Template. If you have a suggestion
*** that would make this better, please fork the repo and create a pull request
*** or simply open an issue with the tag "enhancement".
*** Don't forget to give the project a star!
*** Thanks again! Now go create something AMAZING! :D
-->



<!-- PROJECT SHIELDS -->
<!--
*** I'm using markdown "reference style" links for readability.
*** Reference links are enclosed in brackets [ ] instead of parentheses ( ).
*** See the bottom of this document for the declaration of the reference variables
*** for contributors-url, forks-url, etc. This is an optional, concise syntax you may use.
*** https://www.markdownguide.org/basic-syntax/#reference-style-links
-->
<!--[![Contributors][contributors-shield]][contributors-url]
[![Forks][forks-shield]][forks-url]
[![Stargazers][stars-shield]][stars-url]
[![Issues][issues-shield]][issues-url]-->



<!-- PROJECT LOGO -->
<br />
<div align="center">
  <a href="https://projects.cs.nott.ac.uk/comp2002/2021-2022/team7_project">
    <img src="Program\VI-Resource\images\CapitalOneLogo.png" alt="Logo" height="40%" width="40%">
  </a>

<h3 align="center">CapitalOne - VI Resource</h3>

  <p align="center">
    This tool is being built as part of the COMP2002 Group Project module for CapitalOne. This tool aims to improve the visibility of features included on CapitalOne's site for people with visual impairements.
    <br />
    <a href="https://projects.cs.nott.ac.uk/comp2002/2021-2022/team7_project"><strong>Explore the docs »</strong></a>
    <br />
    <br />
  </p>
</div>



<!-- TABLE OF CONTENTS -->
<details>
  <summary>Table of Contents</summary>
  <ol>
    <li>
      <a href="#about-the-project">About The Project</a>
      <ul>
        <li><a href="#built-with">Built With</a></li>
      </ul>
    </li>
    <li>
      <a href="#getting-started">Getting Started</a>
      <ul>
        <li><a href="#prerequisites">Prerequisites</a></li>
        <li><a href="#installation">Installation</a></li>
      </ul>
    </li>
    <li><a href="#usage">Usage</a></li>
    <li><a href="#contact">Contact</a></li>
  </ol>
</details>



<!-- ABOUT THE PROJECT -->
## About The Project

<p align="center">
    <img src="screenshot.png" alt="Logo" height="60%" width="60%" >
</p>

This tool aims to improve the user experience of the CapitalOne site for those with visual impairements. This is done by implementing different accessibility features in the extension that can be used by people with visual impairements. The features which are being implemented are as follows:
* Increase size of font
* Decrease size of font
* Change font style
* Change colours of contents
* Magnifier
* Audio Prompts

<p align="right">(<a href="#top">back to top</a>)</p>



### Built With

* [JavaScript](https://www.javascript.com/)
* [CSS3](https://developer.mozilla.org/en-US/docs/Web/CSS)
* [HTML5](https://html.spec.whatwg.org/multipage/)


<p align="right">(<a href="#top">back to top</a>)</p>



<!-- GETTING STARTED -->
## Getting Started

To get a local copy up and running follow these simple example steps.

### Prerequisites

This is an example of how to list things you need to use the software and how to install them.
* Install [Chrome](https://support.google.com/chrome/answer/95346?hl=en-GB&co=GENIE.Platform%3DDesktop)

### Installation

1. Clone the repo
   ```sh
   git clone https://projects.cs.nott.ac.uk/comp2002/2021-2022/team7_project
   ```
2. Navigate to the extensions tab on chrome
3. Activate developer mode
4. Click ```Load from unpacked```
5. Select VI-Resource located under Program file

<p align="right">(<a href="#top">back to top</a>)</p>



<!-- USAGE EXAMPLES -->
## Usage

When navigating on a CapitalOne site, click the extension in the top right corner of the browser to open a popup window. This is where you can control the main functions of the program

<p align="right">(<a href="#top">back to top</a>)</p>


<!-- CONTACT -->
## Contact

Maria Ciorba (Team Lead) - [E-mail](mailto:psymc7@nottingham.ac.uk)

Lewis Hughes (Git Admin) - [E-mail](mailto:psylh8@nottingham.ac.uk)

Oliver Gillingham (Team Admin) - [E-mail](mailto:psyog1@nottingham.ac.uk)

Jarred Woolley - [E-mail](mailto:psyjw26@nottingham.ac.uk)

Surina Dhaliwal - [E-mail](mailto:psysd8@nottingham.ac.uk)

Itaiyo Anuwe - [E-mail](mailto:psyia4@nottingham.ac.uk)

Project Link: [https://projects.cs.nott.ac.uk/comp2002/2021-2022/team7_project](https://projects.cs.nott.ac.uk/comp2002/2021-2022/team7_project)

<p align="right">(<a href="#top">back to top</a>)</p>

<!-- MARKDOWN LINKS & IMAGES -->
<!-- https://www.markdownguide.org/basic-syntax/#reference-style-links -->
[contributors-shield]: https://img.shields.io/github/contributors/github_username/repo_name.svg?style=for-the-badge
[contributors-url]: https://projects.cs.nott.ac.uk/comp2002/2021-2022/team7_project/-/graphs/main
[forks-shield]: https://img.shields.io/github/forks/github_username/repo_name.svg?style=for-the-badge
[forks-url]: https://projects.cs.nott.ac.uk/psyjw26/breakout/-/forks/new
[stars-shield]: https://img.shields.io/github/stars/github_username/repo_name.svg?style=for-the-badge
[stars-url]: https://projects.cs.nott.ac.uk/psyjw26/breakout/-/starrers
[issues-shield]: https://img.shields.io/github/issues/github_username/repo_name.svg?style=for-the-badge
[issues-url]: https://github.com/github_username/repo_name/issues
[product-screenshot]: screenshot.png