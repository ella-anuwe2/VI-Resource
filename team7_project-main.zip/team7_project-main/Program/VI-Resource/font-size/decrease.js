var min = 10;
var change = -1;

function changeFontSize(delta){
    
    //Decrease size of p tags
    var tagsP = document.querySelectorAll('p,blockquote');
    //Iterating over array that contains all of the p tags
    for (let i = 0; i < tagsP.length; i++) {
        //Checks if it already has a font size, if so gets it. If not then sets deafult to 30
        if(tagsP[i].style.fontSize){
            var s = parseInt(tagsP[i].style.fontSize.replace("px", ""));
        }else{
            var s = 30;
        }
        //If text is not minimum, sets s to s + delta
        if(s != min){
            s += delta;
        }
        //Sets font size of p tag to s
        tagsP[i].style.fontSize = s + "px";
    }

    //Decrease size of a tags
    var tagsA = document.querySelectorAll('a,blockquote');
    //Iterating over array that contains all of the a tags
    for (let i = 0; i < tagsA.length; i++) {
        //Checks if it already has a font size, if so gets it. If not then sets deafult to 20
        if(tagsA[i].style.fontSize){
            var s = parseInt(tagsA[i].style.fontSize.replace("px", ""));
        }else{
            var s = 20;
        }
        //If text is not minimum, sets s to s + delta
        if(s != min){
            s += delta;
        }
        //Sets font size of a tag to s
        tagsA[i].style.fontSize = s + "px";
    }

    //Decrease the size of buttons
    var tagsButton = document.querySelectorAll('button,blockquote');
    //Iterating over array that contains all of the button tags
    for (let i = 0; i < tagsButton.length; i++) {
        //Checks if it already has a font size, if so gets it. If not then sets deafult to 20
        if(tagsButton[i].style.fontSize){
            var s = parseInt(tagsButton[i].style.fontSize.replace("px", ""));
        }else{
            var s = 20;
        }
        //If text is not minimum, sets s to s + delta
        if(s != min){
            s += delta;
        }
        //Sets font size of button tag to s
        tagsButton[i].style.fontSize = s + "px";
    }

    //Decrease the size of h2
    var tagsH2 = document.querySelectorAll('h2,blockquote');
    //Iterating over array that contains all of the H2 tags
    for (let i = 0; i < tagsH2.length; i++) {
        //Checks if it already has a font size, if so gets it. If not then sets deafult to 20
        if(tagsH2[i].style.fontSize){
            var s = parseInt(tagsH2[i].style.fontSize.replace("px", ""));
        }else{
            var s = 20;
        }
        //If text is not minimum, sets s to s + delta
        if(s != min){
            s += delta;
        }
        //Sets font size of H2 tag to s
        tagsH2[i].style.fontSize = s + "px";
    }
    
    //Decrease the size of li
    var tagsH3= document.querySelectorAll('h3,blockquote');
    //Iterating over array that contains all of the li tags
    for (let i = 0; i < tagsH3.length; i++) {
        //Checks if it already has a font size, if so gets it. If not then sets deafult to 20
        if(tagsH3[i].style.fontSize){
            var s = parseInt(tagsH3[i].style.fontSize.replace("px", ""));
        }else{
            var s = 20;
        }
        //If text is not minimum, sets s to s + delta
        if(s != min){
            s += delta;
        }
        //Sets font size of li tag to s
        tagsH3[i].style.fontSize = s + "px";
    }
    
    //Decrease the size of h3
    var tagsLi = document.querySelectorAll('li,blockquote');
    //Iterating over array that contains all of the H3 tags
    for (let i = 0; i < tagsLi.length; i++) {
        //Checks if it already has a font size, if so gets it. If not then sets deafult to 20
        if(tagsLi[i].style.fontSize){
            var s = parseInt(tagsLi[i].style.fontSize.replace("px", ""));
        }else{
            var s = 20;
        }
        //If text is not minimum, sets s to s + delta
        if(s != min){
            s += delta;
        }
        //Sets font size of H3 tag to s
        tagsLi[i].style.fontSize = s + "px";
    }

    //Decrease small tag
    var tagsSmall = document.querySelectorAll('small,blockquote');
    //Iterating over array that contains all of the small tags
    for (let i = 0; i < tagsSmall.length; i++) {
        //Checks if it already has a font size, if so gets it. If not then sets deafult to 20
        if(tagsSmall[i].style.fontSize){
            var s = parseInt(tagsSmall[i].style.fontSize.replace("px", ""));
        }else{
            var s = 20;
        }
        //If text is not minimum, sets s to s + delta
        if(s != min){
            s += delta;
        }
        //Sets font size of small tag to s
        tagsSmall[i].style.fontSize = s + "px";
    }
}

//Runs when file gets called from popup.js
changeFontSize(change);