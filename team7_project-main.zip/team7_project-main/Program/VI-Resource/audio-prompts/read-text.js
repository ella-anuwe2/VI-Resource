//when enter is clicked and text has been highlighted, the text should be read aloud

function playAudio(){
}