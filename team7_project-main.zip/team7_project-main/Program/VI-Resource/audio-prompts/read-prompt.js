var isMouseHovering = false;

/**we need to check if the component is being hovered over
then read the component description if it is the case
*/

function readAudioPrompt(){
    if(isMouseHovering){
        //read audio prompt
        readDescription(/*button descriptor*/);
    }
}


