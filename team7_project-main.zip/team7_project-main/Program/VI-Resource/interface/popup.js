//Handler for increase button size
document.addEventListener('DOMContentLoaded', function() {
    var checkPageButton = document.getElementById('increase');
    checkPageButton.addEventListener('click', function() {

		chrome.tabs.executeScript(null, {file: "/font-size/increase.js", allFrames: true})
	
    }, false);
}, false);

//Handler for the decrease font size
document.addEventListener('DOMContentLoaded', function() {
    var checkPageButton = document.getElementById('decrease');
    checkPageButton.addEventListener('click', function() {

		chrome.tabs.executeScript(null, {file: "/font-size/decrease.js", allFrames: true})
	
    }, false);
}, false);

//Handler for background colour protanopia
document.addEventListener('DOMContentLoaded', function() {
    var checkPageButton = document.getElementById('protanopia');
    checkPageButton.addEventListener('click', function() {

        chrome.tabs.insertCSS(null, {file: "/colourblind-options/protanopia.css", allFrames: true})
	
    }, false);
}, false);

//Handler for background colour deuteranopia
document.addEventListener('DOMContentLoaded', function() {
    var checkPageButton = document.getElementById('deuteranopia');
    checkPageButton.addEventListener('click', function() {

        chrome.tabs.insertCSS(null, {file: "/colourblind-options/deuteranopia.css", allFrames: true})
	
    }, false);
}, false);

//Handler for background colour tritanopia
document.addEventListener('DOMContentLoaded', function() {
    var checkPageButton = document.getElementById('tritanopia');
    checkPageButton.addEventListener('click', function() {

        chrome.tabs.insertCSS(null, {file: "/colourblind-options/tritanopia.css", allFrames: true})
	
    }, false);
}, false);

//Handler for dyslexic font
document.addEventListener('DOMContentLoaded', function() {
    var checkPageButton = document.getElementById('dyslexia-friendly');
    checkPageButton.addEventListener('click', function() {

        chrome.tabs.insertCSS(null, {file: "/font-style/dyslexia.css", allFrames: true})
	
    }, false);
}, false);

//Handler for easier readability font
document.addEventListener('DOMContentLoaded', function() {
    var checkPageButton = document.getElementById('legible');
    checkPageButton.addEventListener('click', function() {

        chrome.tabs.insertCSS(null, {file: "/font-style/legible.css", allFrames: true})
	
    }, false);
}, false);
